<footer>
        <section id="mapWidget" style="height: 390px;">
            <!-- Map Widget Sample image only -->
            
        </section>
        
        <div class="container-fluid d-flex justify-content-between">
                
                    <div class="container-fluid card-wrapper row justify-content-around">

                    </div>
        </div>

        <div class="jumbotron d-flex justify-content-around mb-1 col-sm-12 bg-dark">
        
          <div class="card bg-secondary text-white" style="width: 18rem;">
            <div class="card-body">
              <h5 class="card-title text-dark">Mount Everest Travels</h5>
              <hr>
              <h6 class="card-subtitle mb-2 text-white">CodeFactory - John Oxales 2020</h6>
              <p class="card-text">Embelgasse 2-8</p>
              <p class="card-text">1050 Wien, Österreich</p>
              <p class="card-text">+43 677 624 79 215</p>
              <a href="#" class="card-link text-white">mount@everest.com</a>
              
            </div>
          </div>

          <div class="card" style="width: 18rem;">
            <div class="card-body bg-secondary">
              <h5 class="card-title">Info</h5>
              <hr>
              <a href="#" class="card-text text-white"><p>Contact</p></a>
              <a href="#" class="card-text text-white"><p>Imprint</p></a>
              <a href="#" class="card-text text-white"><p>Privacy</p></a>
              <a href="#" class="card-text text-white"><p>Terms of condition</p></a>
              <a href="#" class="card-text text-white"><p>Home</p></a>
             
            </div>
          </div>

          <div class="card bg-secondary" style="width: 18rem;">
            <div class="card-body">
              <h5 class="card-title">Services</h5>
              <hr>
              <a href="#" class="card-text text-white"><p>Blog</p></a>
              <a href="#" class="card-text text-white"><p>Business</p></a>
              <a href="#" class="card-text text-white"><p>Personal Branding</p></a>
              <a href="#" class="card-text text-white"><p>Gallery</p></a>
              <a href="#" class="card-text text-white"><p>Applications</p></a>
              
            </div>
          </div>
          
    </footer>


</body>
<?php wp_footer(); ?> 
</html>