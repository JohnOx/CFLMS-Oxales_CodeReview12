<?php get_header(); ?>
  

<!-- dynamic content  -->

<section id="1">
        <div class="jumbotron jumbotron-fluid">
            <div class="text-center">
                
                <h1 class="display-3">Some section text goes in here</h1>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Laudantium magni repellat nisi sequi, repellendus vero a placeat beatae possimus aspernatur veritatis, in voluptas molestias asperiores quo reiciendis exercitationem quod amet.</p>
            </div>
        </div>
    </section>

    <section id="2">
        <div class="row d-flex position-relative">
            <div class="col-md-3 d-flex">
                <div class="media block-6 d-block text-center">
                    <div class="d-flex justify-content-center">
                        <img src="https://cdn.pixabay.com/photo/2016/11/23/15/32/architecture-1853552_960_720.jpg" alt="one" style="width:33vw; height: 30vh;">
                        <img src="https://cdn.pixabay.com/photo/2015/04/20/13/44/sports-731506_960_720.jpg" alt="two" style="width:33vw; height: 30vh;">
                        <img src="https://cdn.pixabay.com/photo/2015/12/08/00/40/empire-state-building-1081929_960_720.jpg" alt="three" style="width:33vw; height: 30vh;">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <hr>

    <section id="3">
        <div class="jumbotron jumbotron-fluid d-flex">

            <div class="text-center">
                
                <h1 class="display-3">Some other section text goes in here</h1>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Laudantium magni repellat nisi sequi, repellendus vero a placeat beatae possimus aspernatur veritatis, in voluptas molestias asperiores quo reiciendis exercitationem quod amet.</p>
            </div>

             <!-- Some customizable Widget -->
                <div style="border: dotted black 1px; border-radius: 5px;">
                
                    <?php
                        if(is_active_sidebar('sidebar')):
                            dynamic_sidebar('sidebar');
                        endif;  
                    ?>

                </div>

        </div>
    </section>

    <section id="gallerySlide">
        <div class="container-fluid">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="https://cdn.pixabay.com/photo/2016/11/30/15/00/lighthouse-1872998_960_720.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="https://cdn.pixabay.com/photo/2017/08/31/05/36/new-york-2699520_960_720.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="https://cdn.pixabay.com/photo/2020/04/30/02/14/bali-5111131_960_720.jpg" class="d-block w-100" alt="...">
                </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </section>

    <hr>
  <div class="container">
    <section class="row d-flex flex-wrap justify-content-center" id=blog>

    <!-- <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 border d-flex flex-wrap justify-content-around"> -->


        <?php if(have_posts()) : ?> <!--  If there are posts available  -->
            
                
                <div class="card-group container-fluid">
                    
                    <?php while(have_posts()) : the_post(); ?>
                                <div class="card" style="width: 24rem;">
                                        <img src="https://cdn.pixabay.com/photo/2018/04/21/14/17/raise-3338589_960_720.jpg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <h5 class="card-title"><a href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
                                                                <?php the_title(); ?>     <!--retrieves blog title-->
                                                                </a></h5>
                                        <p class="card-text"><?php the_excerpt(); ?></p>
                                    </div>
                                <div class="card-footer">
                                    <small class="text-muted">Last updated <?php the_time('F j, Y g:i a'); ?></small>
                                    <small class="text-muted">by  <?php the_author(); ?></small>
                                </div>
                        
                    <?php endwhile; ?><!--end the while loop-->
                
                </div>
                    
    
            <?php else :?> <!-- if no posts are found then: -->

                <p>No posts found</p>

        <?php endif; ?>
        
    </div>
    </section>
    </div><!--container fluid-->



<hr>

<?php get_footer(); ?>