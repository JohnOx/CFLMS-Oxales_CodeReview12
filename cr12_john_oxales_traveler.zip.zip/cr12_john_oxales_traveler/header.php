<!DOCTYPE html>
<html>


 <head>

   <meta charset="<?php bloginfo('charset'); ?>"><!--displays the encoding-->
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
   <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
  

   <?php wp_head(); ?> 

 </head>



 <body>
    <!-- Start of NavBar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  
        <a class="navbar-brand text-white" href="#">Mount Everest Travels</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon text-white"></span>
            </button>
            <?php
            wp_nav_menu( array(
                'theme_location'    => 'primary',// refers to the key in functions
                'depth'             => 2, // 1 = no dropdowns, 2 = with dropdowns.
                'container'         => 'div', //container around menu
                'container_class'   => 'collapse navbar-collapse',//bs-class
                'container_id'      => 'bs-example-navbar-collapse-1',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                'walker'            => new WP_Bootstrap_Navwalker(),
            ) );
            ?>
        
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
        
            <ul class="navbar-nav mr-auto">
        
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Dropdown Menu
                </a>
        
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </li>
              
            </ul>
           
          </div>
        
    </nav>

    

    <div class="jumbotron jumbotron-fluid" id="hero">
        <div class="container-fluid">
            <h1 class="display-3 text-center">Mount Everest Travels</h1>
            
        </div>
    </div><!--hero-->